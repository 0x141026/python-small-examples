=============================
第十五章：TensorFlow
=============================

TensorFlow集成了Keras里面的优化器，TensorFlow 2.0 使用动态图，调试程序方便很多。




.. toctree::
   :maxdepth: 1
   :glob:

   ../ch15/*
