=============================
第九章：迭代器
=============================

Python迭代器(iterator)是使用频率很高的数据类型，模块 ``collections.abc`` 封装了 `` Iterable`` 可迭代类型
对象。




.. toctree::
   :maxdepth: 1
   :glob:

   ../ch09/*
