=============================
第七章：绘图
=============================

Python的绘图库常用的有 ``matplotlib`` , ``plotly`` , ``seaborn`` 
还有能展示绘图轨迹的库 ``turtle`` , 绘制云图的 ``wordcloud`` ，本章总结这些库绘图的最常用用法。




.. toctree::
   :maxdepth: 1
   :glob:

   ../ch07/*
