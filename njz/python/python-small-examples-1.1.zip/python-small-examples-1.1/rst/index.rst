.. python-small-examples documentation master file, created by
   sphinx-quickstart on Tue Dec 19 03:21:45 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

================================================
Python small-examples Documentation
================================================

Contents:

.. toctree::
   :maxdepth: 2
   :glob:
   

   preface
   chapters/*
   aboutme
