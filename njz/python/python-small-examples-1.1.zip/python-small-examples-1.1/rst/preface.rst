==============================
前言
==============================

---------------------------
Python 小例子
---------------------------

告别枯燥，60秒学会一个Python小例子。Python基础、Web开发、数据科学、机器学习的精简小例子都在这里。

我们会一直每天更新一个小例子，欢迎您的 star.

https://github.com/jackzhenguo/python-small-examples

----------
欢迎贡献
----------

比如github账号为`lhxon`的小伙伴，star 和 fork此库后，按照如下步骤提交到此库的md 文件夹：


1. git clone https://github.com/lhxon/python-small-examples
2. git add . 
3. git commit -m "xiugai"
4. git push
5. 界面点击：pull requests，根据操作即可。如遇问题，欢迎联系我。


