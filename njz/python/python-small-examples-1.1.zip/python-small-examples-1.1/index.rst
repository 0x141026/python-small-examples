.. toctree::
   :maxdepth: 2
   :glob:

   rst/README.rst
   rst/preface
   rst/chindex/*
   rst/aboutme