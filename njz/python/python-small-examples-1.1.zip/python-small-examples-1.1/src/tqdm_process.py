from tqdm import tqdm
import time
# for i in tqdm(range(10)):  # tqdm构造函数包装range
#     time.sleep(0.2)


# 设置进度条的总长度
# with tqdm(total=10) as pbar:
#     for i in range(100):
#         time.sleep(0.05)
#         # 每次更新进度条的长度
#         pbar.update(1)


# with tqdm(total=100) as pbar:
#     for i in range(10):
#         time.sleep(0.1)
#         pbar.update(10)
