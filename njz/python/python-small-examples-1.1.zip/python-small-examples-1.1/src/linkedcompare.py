i = 3
print(1 < i < 3)  # False
print(1 < i <= 3)  # True
