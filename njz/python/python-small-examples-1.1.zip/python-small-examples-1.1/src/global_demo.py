i = 0


def h():
    global i
    i += 1


h()
print(i)
